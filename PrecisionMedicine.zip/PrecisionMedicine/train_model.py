import pandas as pd
import pickle
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.multioutput import MultiOutputClassifier

# Load dataset
df = pd.read_csv('combined_skin_hair_symptom_dataset_100.csv')

# Standardize column names and values
df.columns = [col.lower().strip() for col in df.columns]
for col in df.columns:
    if df[col].dtype == 'object':
        df[col] = df[col].str.lower().str.strip()

# Rename duration column for easier access
df.rename(columns={'duration (days)': 'duration_days'}, inplace=True)

# Drop rows with missing values in key columns
required_cols = ['gender', 'age group', 'symptom', 'severity', 'duration_days',
                 'condition', 'suggested remedy', 'side effects']
df.dropna(subset=required_cols, inplace=True)

# Label encode input features
le_gender = LabelEncoder()
le_age = LabelEncoder()
le_symptom = LabelEncoder()
le_severity = LabelEncoder()

df['gender'] = le_gender.fit_transform(df['gender'])
df['age group'] = le_age.fit_transform(df['age group'])
df['symptom'] = le_symptom.fit_transform(df['symptom'])
df['severity'] = le_severity.fit_transform(df['severity'])

# Input features and output labels
X = df[['gender', 'age group', 'symptom', 'duration_days', 'severity']]
y = df[['condition', 'suggested remedy', 'side effects']]

# Label encode outputs
y_encoded = pd.DataFrame()
output_encoders = {}

for col in y.columns:
    le = LabelEncoder()
    y_encoded[col] = le.fit_transform(y[col])
    output_encoders[col] = le

# Train model
model = MultiOutputClassifier(RandomForestClassifier(random_state=42))
model.fit(X, y_encoded)


# Save model
with open('model.pkl', 'wb') as f:
    pickle.dump(model, f)

# Save encoders
with open('encoders.pkl', 'wb') as f:
    pickle.dump({
        'gender': le_gender,
        'age': le_age,
        'symptom': le_symptom,
        'severity': le_severity,
        'output': output_encoders
    }, f)

print("✅ Model trained and saved successfully.")