from flask import Flask, request, render_template
import pickle
import numpy as np

app = Flask(__name__)

# Load model and encoders
with open('model.pkl', 'rb') as f:
    model = pickle.load(f)

with open('encoders.pkl', 'rb') as f:
    encoders = pickle.load(f)

# Load individual encoders
try:
    le_gender = encoders['gender']
    le_age = encoders['age']
    le_symptom = encoders['symptom']
    le_severity = encoders['severity']
    output_encoders = encoders['output']
except KeyError as e:
    raise Exception(f"Missing encoder: {e}")

# Home route
@app.route('/')
def home():
    return render_template('index.html')

# Predict route
@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get form data
        name = request.form.get('name', '').strip()
        gender = request.form.get('gender', '').strip().lower()
        age_group = request.form.get('age_group', '').strip().lower()
        symptom = request.form.get('symptom', '').strip().lower()
        duration_days = int(request.form.get('duration_days', 0))
        severity = request.form.get('severity', '').strip().lower()

        # Encode input values
        gender_encoded = le_gender.transform([gender])[0]
        age_encoded = le_age.transform([age_group])[0]
        symptom_encoded = le_symptom.transform([symptom])[0]
        severity_encoded = le_severity.transform([severity])[0]

        # Prepare input for prediction
        input_data = np.array([[gender_encoded, age_encoded, symptom_encoded, duration_days, severity_encoded]])

        # Make prediction
        predictions = model.predict(input_data)[0]

        # Decode predictions
        decoded = {}
        for i, col in enumerate(output_encoders):
            decoded[col] = output_encoders[col].inverse_transform([predictions[i]])[0]

        return render_template('result.html', name=name, prediction=decoded)

    except ValueError as ve:
        return f"❌ Value Error during prediction: {str(ve)}"
    except Exception as e:
        return f"❌ Error during prediction: {str(e)}"

# Correct main entry point
if __name__ == '__main__':
    app.run(debug=True)
